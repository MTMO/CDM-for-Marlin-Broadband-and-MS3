var searchData=
[
  ['evaluatelicense',['evaluateLicense',['../classmarlincdm_1_1_marlin_agent_handler.html#a309a76c82a232cf1e583d461c8d4a281',1,'marlincdm::MarlinAgentHandler']]]
];
