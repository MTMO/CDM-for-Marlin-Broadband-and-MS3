var searchData=
[
  ['serviceidbuf',['serviceidbuf',['../struct_m_h__action_result__t.html#a206456c8a119eeabf6c48c37e57b1ce5',1,'MH_actionResult_t']]],
  ['serviceinfobuf',['serviceinfobuf',['../struct_m_h__action_result__t.html#a81ea4915794fa983ac2943708f986ab0',1,'MH_actionResult_t']]]
];
