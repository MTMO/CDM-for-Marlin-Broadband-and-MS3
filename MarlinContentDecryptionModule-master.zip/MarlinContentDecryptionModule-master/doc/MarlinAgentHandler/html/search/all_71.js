var searchData=
[
  ['querylicensestatus',['queryLicenseStatus',['../classmarlincdm_1_1_marlin_agent_handler.html#a44df5bd815083287002c9ded4ae7bc29',1,'marlincdm::MarlinAgentHandler']]]
];
