var searchData=
[
  ['closesession',['CloseSession',['../classmarlincdm_1_1_marlin_cdm_interface.html#a27a2e542ab8bdbd61f8cabf6339d1460',1,'marlincdm::MarlinCdmInterface']]]
];
