var searchData=
[
  ['opensession',['OpenSession',['../classmarlincdm_1_1_marlin_cdm_interface.html#acca8e140a5ebfab35715c91aaee09371',1,'marlincdm::MarlinCdmInterface']]]
];
