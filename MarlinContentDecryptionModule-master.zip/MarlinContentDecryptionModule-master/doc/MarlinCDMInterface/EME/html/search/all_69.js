var searchData=
[
  ['istypesupported',['isTypeSupported',['../classmarlincdm_1_1_marlin_cdm_interface.html#a075ad3e9c5843eb03c1cb82adbb2fbdd',1,'marlincdm::MarlinCdmInterface']]]
];
