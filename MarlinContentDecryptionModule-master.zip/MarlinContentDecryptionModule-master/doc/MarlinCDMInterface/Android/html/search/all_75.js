var searchData=
[
  ['usesecurebuffer',['useSecureBuffer',['../classmarlincdm_1_1_marlin_cdm_interface.html#a6f8e7f6556b5130344d5efd64fb327c7',1,'marlincdm::MarlinCdmInterface']]]
];
