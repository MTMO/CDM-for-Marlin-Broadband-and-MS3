var searchData=
[
  ['removekey',['RemoveKey',['../classmarlincdm_1_1_marlin_cdm_interface.html#adb1de3b8d50a7d6d05442e6c5fa81502',1,'marlincdm::MarlinCdmInterface']]],
  ['restorekey',['RestoreKey',['../classmarlincdm_1_1_marlin_cdm_interface.html#a9025ac0785fe5e3340d81c246fbe931e',1,'marlincdm::MarlinCdmInterface']]]
];
